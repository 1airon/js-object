// BEGIN
const json = () => {
    return {
        "files": [
          "src/objects.js"
        ],
        "config": true
      } 
}
export default json;
    



// END